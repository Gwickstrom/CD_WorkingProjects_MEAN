Friends API
Let’s use that nice file structure we created in that last assignment as a starting point.

We are going to work in 3 files that we previously created: server.js, routes.js, and mongoose.js; and create 2 more folders if we don’t already have them: models and controllers.

In models, we are going to put a friend.js file.      In controllers, we are going to put a friends.js file.

We provide a quick update to server.js, full code for mongoose.js (minus the DB name which you will have to provide), and most of the code for the routes.js (minus a require of the controllers/friends.js file).

We provide a template for the controllers/friends.js file but the methods need to be fleshed out.

We provide a very barebone models/friend.js file, which will also need to be filled out.

USE 1955 API and resources from the mongo chapter to help you finish this!!!

Keep in mind, the code snippets below may need additions to be complete

Let’s start with server.js: We’ve already required routes.js and routes.js exports an empty function with a parameter app. Let’s pass our server app into that function as an argument.

server.js
this is just a line adjustment, not the whole file!
//... express, path, app, etc
require("./server/config/routes.js")(app);
//... app listen ...

Since routes.js exports a function require("./server/config/routes.js") IS A FUNCTION!
Now we invoke it, passing it app! require("./server/config/routes.js")(app);

In our routes.js file:
WE NEED TO ADD a few lines of code up here! What is this 'friends' object we are referencing below??
console.log('routes');
module.exports = function(app){
app.get('/friends', function(req, res) {
  friends.index(req, res);
});
app.get('/friends/:id', function(req, res) {
  friends.show(req, res);
});
app.post('/friends', function(req, res) {
  friends.create(req, res);
});
app.put('/friends/:id', function(req, res) {
  friends.update(req, res);
});
app.delete('/friends/:id', function(req, res) {
  friends.delete(req, res);
});
}
// this adds route listeners to friends for 5 of the 7 RESTful routes, excluding new and edit.

In our mongoose.js files
don’t forget to change the DB Name!
// require mongoose
var mongoose = require('mongoose');
// require the fs module for loading model files
var fs = require('fs');
// require path for getting the models path
var path = require('path');
// connect to mongoose!
mongoose.connect('mongodb://localhost/DBNAMEGOESHERE');// create a variable that points to the path where all of the models live
var models_path = path.join(__dirname, './../models');
// read all of the files in the models_path and require (run) each of the javascript files
fs.readdirSync(models_path).forEach(function(file) {
if(file.indexOf('.js') >= 0) {
  // require the file (this runs the model file which registers the schema)
  require(models_path + '/' + file);
}
});

A few more set-up pieces!

controllers/friends.js
WE NEED TO ADD A FEW lines of code here!How does a controller talk to mongoose and get a model?Build out the methods in the friendsControllers belowWhat does the module.exports export?
console.log('friends controller');
module.exports = {
  index: function(req,res){
    //your code here
    res.json({placeholder:'index'});
  },
  create: function(req,res){
    //your code here
    res.json({placeholder:'create'});
  },
  update: function(req,res){
    //your code here
    res.json({placeholder:'update'});
  },
  delete: function(req,res){
    //your code here
    res.json({placeholder:'delete'});
  },
  show: function(req,res){
    //your code here
    res.json({placeholder:'show'});
  }
}

models/friend.js
build your friend schema and add it to the mongoose.models
console.log('friends model');
var mongoose = require('mongoose');


Assignment Goal Summary:
1) require the correct files and set the appropriate variables for the routes.js file to work.

2) require the correct files and set the correct variables for the controllers/friends.js file to appropriately communicate with your DB and perform the indicated RESTful routes.

3) require the correct files and generate a fitting model for friends in the models/friend.js file. (To test your index method and show method, try populating your DB using the mongo shell).

The remaining methods we will have to test using other AJAX or Angular or HTML forms (for post, put, delete routes), which we will do in two tabs.
