File Structure and Simple Server
The goal of this assignment is to build a simple Express server. This server should:

Be able to serve static files from ./client, and ./bower_components. Render index.html when a user hits the root route ‘/’ that has "Welcome" in the body. require body-parser. Be able to explain what body-parser does. require a mongoose.js file from “./server/config”. To confirm that the mongoose.js file loads have the top of this file console.log(‘future mongoose connection and model loading’); require a routes.js file from “./server/config”. To confirm that the routes.js loads have the routes.js console.log(‘future routes’). The routes.js file should export an empty function that has a parameter (app); Listen at a port of your choosing.

The file structure might look something like this! (and a node_modules folder will be pushed in if you run npm install)

This and the next few assignments are all about building out this wireframe. Server -> Model -> API -> Angular -> Expand
Take it one step at a time!
