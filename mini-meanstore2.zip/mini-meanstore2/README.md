# mini-meanstore2

The mini-meanstore is a coding dojo project. That I have adapted with bootstrap to give it some color and a few add ons.
# meanStoreBasicNoFrontEnd
