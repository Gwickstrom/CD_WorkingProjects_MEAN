Angular Friends

So now that we have our Friends API up and running:

It’s time to work on the Angular side of things!

Part I: We are going to work on four files, all inside of client.

partials/new.html        partials/edit.html       assets/app.js        index.html

Beginning of index.html
<!DOCTYPE html>
<!-- DONT FORGET TO ADD YOUR ANGULAR APP! -->
<html>
  <head>
    <meta charset="utf-8">
    <title>Awesome Friends</title>
    <!-- Angular from bower_components, otherwise find the CDN -->
    <script src="angular/angular.js" charset="utf-8"></script>
    <script src="angular-route/angular-route.js" charset="utf-8"></script>
    <!-- End Bower Components -->
    <script src="assets/app.js" charset="utf-8"></script>
  </head>
  <body>
    <!-- Links to your new and edit pages here.  Review Angular Partials if you've forgotten ) -->
    <!-- not so subtle hint: ng-view ??? -->
  </body>
</html>


app.js

var app = angular.module('app', ['ngRoute']);
app.config(function ($routeProvider) {
// Routes to load your new and edit pages with new and edit controllers attached to them!
});


partials/new and partials/edit

<!-- You will attach an ng-model and an ng-submit to your forms (but might want to wait until the next tab, when you have your controllers and factory) -->
<form>
  <!-- Appropriate inputs here! -->
</form>

By the end of this assignment, you should have forms where you can create and edit users (but if you are following along, they should neither create nor edit users just yet).
