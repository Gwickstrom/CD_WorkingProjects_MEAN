Assignment: Login and Registration
Create a login and registration that uses back-end validation, catches errors and returns them to an Angular factory. Have a login controller that can differentiate between a proper login and errors. If there are errors show the errors using angular (ng-show/ng-if/ng-hide might help), otherwise set the newly logged-in user or registered user to a variable in the factory that is retrieved by the controller.


Required Registration Fields:

email     first_name    last_name    password     password_confirm     birthday


Each registration field should have at least one back-end validation on it! Besides password_confirmation.

email should use a unique:true as one of key:value pairs in the objects schema. How are we going to deal with uniqueness errors (note the error object from unique:true is different!)?

The login form should just have password and email.

Your factory should have a logout method that removes the user and redirects back to the login and registration form (or other location of your choice).

You can use front-end validations in addition if you want

https://docs.angularjs.org/guide/forms
